﻿using System;
using Org.Juipp.Core.Events.Arguments;

namespace $rootnamespace$.Behaviors
{
    public partial class OpenDefaultBehavior
    {
    }
}
