﻿namespace $rootnamespace$.ViewModels
{
    public partial class DefaultViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
